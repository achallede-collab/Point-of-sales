const express = require('express');
const { v4: uuidv4 } = require('uuid');
const { body, validationResult } = require('express-validator');
const db = require('../db/db');
const { requireAuth } = require('../middleware/auth');
const { logActivity } = require('../services/activity');

const router = express.Router();
router.use(requireAuth);

/**
 * GET /api/appointments?from=&to=&status=
 * Returns appointments in a date range, e.g. for a calendar/week view.
 */
router.get('/', (req, res) => {
  const { from, to, status } = req.query;
  const clauses = ['business_id = ?'];
  const params = [req.user.businessId];

  if (from) { clauses.push('starts_at >= ?'); params.push(from); }
  if (to) { clauses.push('starts_at <= ?'); params.push(to); }
  if (status) { clauses.push('status = ?'); params.push(status); }

  const rows = db
    .prepare(`SELECT * FROM appointments WHERE ${clauses.join(' AND ')} ORDER BY starts_at ASC`)
    .all(...params);

  res.json({ appointments: rows });
});

/**
 * POST /api/appointments
 * Books a client appointment. reminder_offset_minutes controls how long
 * before starts_at the reminder job (see services/reminders.js) will fire.
 */
router.post(
  '/',
  [
    body('title').trim().notEmpty(),
    body('client_name').trim().notEmpty(),
    body('starts_at').isISO8601().withMessage('starts_at must be a valid ISO date/time'),
  ],
  (req, res) => {
    const errors = validationResult(req);
    if (!errors.isEmpty()) return res.status(400).json({ errors: errors.array() });

    const {
      title, client_name, client_phone, location, starts_at,
      duration_minutes, reminder_offset_minutes, lead_id, notes,
    } = req.body;

    const id = uuidv4();
    db.prepare(
      `INSERT INTO appointments
        (id, business_id, lead_id, title, client_name, client_phone, location, starts_at, duration_minutes, reminder_offset_minutes, notes)
       VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`
    ).run(
      id, req.user.businessId, lead_id || null, title, client_name, client_phone || null,
      location || null, starts_at, duration_minutes || 30, reminder_offset_minutes ?? 60, notes || null
    );

    logActivity(req.user.businessId, 'appointment', id, 'booked', `${title} with ${client_name}`);

    const appt = db.prepare('SELECT * FROM appointments WHERE id = ?').get(id);
    res.status(201).json(appt);
  }
);

/**
 * PATCH /api/appointments/:id
 * Reschedule, mark completed/cancelled/no-show, or edit details.
 */
router.patch('/:id', (req, res) => {
  const existing = db
    .prepare('SELECT * FROM appointments WHERE id = ? AND business_id = ?')
    .get(req.params.id, req.user.businessId);
  if (!existing) return res.status(404).json({ error: 'Appointment not found.' });

  const fields = [
    'title', 'client_name', 'client_phone', 'location', 'starts_at',
    'duration_minutes', 'status', 'reminder_offset_minutes', 'notes',
  ];
  const updates = [];
  const params = [];
  for (const f of fields) {
    if (req.body[f] !== undefined) {
      updates.push(`${f} = ?`);
      params.push(req.body[f]);
    }
  }
  // If the time changes, allow the reminder to be sent again
  if (req.body.starts_at !== undefined) {
    updates.push('reminder_sent = 0');
  }
  if (updates.length === 0) return res.status(400).json({ error: 'No fields to update.' });

  params.push(req.params.id, req.user.businessId);
  db.prepare(`UPDATE appointments SET ${updates.join(', ')} WHERE id = ? AND business_id = ?`).run(...params);

  logActivity(req.user.businessId, 'appointment', req.params.id, 'updated', JSON.stringify(req.body));

  const updated = db.prepare('SELECT * FROM appointments WHERE id = ?').get(req.params.id);
  res.json(updated);
});

router.delete('/:id', (req, res) => {
  const result = db
    .prepare('DELETE FROM appointments WHERE id = ? AND business_id = ?')
    .run(req.params.id, req.user.businessId);
  if (result.changes === 0) return res.status(404).json({ error: 'Appointment not found.' });
  res.status(204).send();
});

module.exports = router;
