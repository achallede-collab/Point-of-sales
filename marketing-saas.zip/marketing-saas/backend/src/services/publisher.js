const db = require('../db/db');
const { v4: uuidv4 } = require('uuid');
const meta = require('./social/meta');
const twitter = require('./social/twitter');
const linkedin = require('./social/linkedin');

/**
 * Publishes a single campaign to every platform it targets, using whichever
 * social_accounts row the business has connected for that platform.
 * Records one campaign_results row per platform so success/failure and
 * the resulting post id can be tracked.
 */
async function publishCampaign(campaign) {
  const platforms = JSON.parse(campaign.platforms || '[]');
  const results = [];

  for (const platform of platforms) {
    const account = db
      .prepare(`SELECT * FROM social_accounts WHERE business_id = ? AND platform = ? AND status = 'connected'`)
      .get(campaign.business_id, platform);

    const resultId = uuidv4();

    if (!account) {
      db.prepare(
        `INSERT INTO campaign_results (id, campaign_id, platform, status, error_message) VALUES (?, ?, ?, 'failed', ?)`
      ).run(resultId, campaign.id, platform, `No connected ${platform} account for this business.`);
      results.push({ platform, status: 'failed' });
      continue;
    }

    try {
      let response;
      if (platform === 'facebook' || platform === 'instagram') {
        response = await meta.publishToPage(account, campaign.message, campaign.media_url);
      } else if (platform === 'twitter') {
        response = await twitter.publishTweet(account, campaign.message);
      } else if (platform === 'linkedin') {
        response = await linkedin.publishPost(account, campaign.message);
      } else {
        throw new Error(`Publishing to ${platform} is not implemented yet.`);
      }

      db.prepare(
        `INSERT INTO campaign_results (id, campaign_id, platform, external_post_id, status) VALUES (?, ?, ?, ?, 'success')`
      ).run(resultId, campaign.id, platform, response?.id || response?.data?.id || null);
      results.push({ platform, status: 'success' });
    } catch (err) {
      const message = err.response?.data ? JSON.stringify(err.response.data) : err.message;
      db.prepare(
        `INSERT INTO campaign_results (id, campaign_id, platform, status, error_message) VALUES (?, ?, ?, 'failed', ?)`
      ).run(resultId, campaign.id, platform, message);
      results.push({ platform, status: 'failed', error: message });
    }
  }

  const overallStatus = results.some((r) => r.status === 'success') ? 'posted' : 'failed';
  db.prepare(`UPDATE campaigns SET status = ?, posted_at = datetime('now') WHERE id = ?`).run(overallStatus, campaign.id);

  return results;
}

module.exports = { publishCampaign };
