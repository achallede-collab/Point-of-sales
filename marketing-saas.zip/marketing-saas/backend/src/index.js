require('dotenv').config();
const express = require('express');
const cors = require('cors');

require('./db/db'); // ensures schema is created on boot

const authRoutes = require('./routes/auth');
const businessRoutes = require('./routes/business');
const leadsRoutes = require('./routes/leads');
const appointmentsRoutes = require('./routes/appointments');
const socialRoutes = require('./routes/social');
const campaignsRoutes = require('./routes/campaigns');
const dashboardRoutes = require('./routes/dashboard');

const { startReminderScheduler } = require('./services/reminders');
const { startCampaignScheduler } = require('./services/campaignScheduler');

const app = express();

app.use(cors({ origin: process.env.CLIENT_ORIGIN || '*' }));
app.use(express.json());

app.get('/api/health', (req, res) => res.json({ status: 'ok', time: new Date().toISOString() }));

app.use('/api/auth', authRoutes);
app.use('/api/business', businessRoutes);
app.use('/api/leads', leadsRoutes);
app.use('/api/appointments', appointmentsRoutes);
app.use('/api/social', socialRoutes);
app.use('/api/campaigns', campaignsRoutes);
app.use('/api/dashboard', dashboardRoutes);

// Centralized error handler (catches anything thrown/rejected in routes)
app.use((err, req, res, next) => {
  console.error(err);
  res.status(500).json({ error: 'Something went wrong on our end.' });
});

const PORT = process.env.PORT || 4000;
app.listen(PORT, () => {
  console.log(`Marketing SaaS API running on http://localhost:${PORT}`);
  startReminderScheduler();
  startCampaignScheduler();
});
