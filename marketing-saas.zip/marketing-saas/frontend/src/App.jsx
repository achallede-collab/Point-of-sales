import React from 'react';
import { Routes, Route } from 'react-router-dom';
import ProtectedRoute from './components/ProtectedRoute.jsx';
import DashboardLayout from './components/DashboardLayout.jsx';

import Login from './pages/Login.jsx';
import Register from './pages/Register.jsx';
import Overview from './pages/Overview.jsx';
import Leads from './pages/Leads.jsx';
import Appointments from './pages/Appointments.jsx';
import Campaigns from './pages/Campaigns.jsx';
import SocialSettings from './pages/SocialSettings.jsx';
import TeamSettings from './pages/TeamSettings.jsx';

export default function App() {
  return (
    <Routes>
      <Route path="/login" element={<Login />} />
      <Route path="/register" element={<Register />} />

      <Route
        path="/"
        element={
          <ProtectedRoute>
            <DashboardLayout />
          </ProtectedRoute>
        }
      >
        <Route index element={<Overview />} />
        <Route path="leads" element={<Leads />} />
        <Route path="appointments" element={<Appointments />} />
        <Route path="campaigns" element={<Campaigns />} />
        <Route path="settings/social" element={<SocialSettings />} />
        <Route path="settings/team" element={<TeamSettings />} />
      </Route>
    </Routes>
  );
}
