# Outpost — Multi-tenant Social Media Marketing & CRM

A full-stack starter for a SaaS that businesses use to run social media
marketing and manage their sales pipeline:

- **Multi-tenant**: every business that signs up gets its own isolated dashboard, data, and team.
- **Social media hub**: connect Facebook, Instagram, X (Twitter), and LinkedIn, then create one campaign that posts to all of them.
- **Lead generation & CRM**: capture leads with name, phone number, and location; track them through a pipeline (new → contacted → qualified → won/lost); see the full follow-up timeline per prospect.
- **Appointments & reminders**: book client appointments and automatically send a reminder before each one.
- **Team access**: business owners can invite staff/admins onto the same dashboard.

## Structure
```
marketing-saas/
  backend/     Express + SQLite API (see backend/README.md)
  frontend/    React + Vite + Tailwind dashboard (see frontend/README.md)
```

## Quick start
Two terminals:

```bash
# Terminal 1 — API
cd backend
npm install
cp .env.example .env        # set JWT_SECRET
npm run seed                  # optional demo data (demo@example.com / password123)
npm run dev                    # http://localhost:4000

# Terminal 2 — Dashboard
cd frontend
npm install
cp .env.example .env
npm run dev                    # http://localhost:5173
```

Then open http://localhost:5173/register to create a business, or
http://localhost:5173/login with the seeded demo account.

## What's stubbed vs. real
- **Real**: auth, multi-tenancy, lead CRUD + pipeline, appointment booking + cron-based reminders, campaign creation/scheduling, the OAuth *code paths* and API call shapes for Facebook/Instagram/X/LinkedIn.
- **Needs your own credentials to go live**:
  - Social platform posting — create a developer app per platform and add the keys to `backend/.env` (see `backend/README.md`).
  - SMS/email reminders — `backend/src/services/notifications.js` currently logs to the console; swap in Twilio, an email provider, or WhatsApp Business API.

## Extending this
- Swap SQLite for Postgres by changing `backend/src/db/db.js` to a `pg` connection and updating the `CREATE TABLE` statements (mostly compatible SQL already).
- Add billing (Stripe subscriptions per business) by adding a `subscriptions` table keyed on `business_id`.
- Add a public lead-capture form (e.g. `/l/:businessSlug`) that posts to `POST /api/leads` with a business-scoped API key, so businesses can embed a form on their own website or landing pages built from ad campaigns.
