# Marketing SaaS — Frontend

React + Vite + Tailwind dashboard for the multi-tenant marketing/CRM backend.
Each business gets its own login and its own scoped dashboard (leads,
appointments, campaigns, connected social accounts).

## Setup
```bash
cd frontend
npm install
cp .env.example .env   # point VITE_API_URL at your backend if not localhost:4000
npm run dev             # http://localhost:5173
```

## Pages
- `/register` — a new business signs up and gets a dashboard
- `/login` — sign in
- `/` — overview (lead stats, upcoming appointments, connected platforms)
- `/leads` — capture and manage leads (name, phone, location, source, pipeline status)
- `/appointments` — book client appointments with automatic reminders
- `/campaigns` — create & publish/schedule social posts across connected platforms
- `/settings/social` — connect/disconnect Facebook, Instagram, X, LinkedIn
- `/settings/team` — invite teammates onto the same business dashboard

## Notes
- Auth token is stored in `localStorage` and attached to every API request (`src/api/client.js`).
- `src/context/AuthContext.jsx` holds the logged-in user + business and re-hydrates on refresh via `GET /auth/me`.
- Styling uses Tailwind with a small custom design token set in `tailwind.config.js` (deep emerald "signal" color, warm amber accent, serif display font paired with Inter).
