const cron = require('node-cron');
const db = require('../db/db');
const { logActivity } = require('./activity');
const { sendSms } = require('./notifications');

/**
 * Every minute, look for appointments whose reminder window has arrived
 * and hasn't been sent yet, then "send" a reminder (SMS/notification stub -
 * wire up a real SMS provider such as Twilio in services/notifications.js).
 */
function startReminderScheduler() {
  cron.schedule('* * * * *', () => {
    const due = db
      .prepare(
        `SELECT * FROM appointments
         WHERE status = 'scheduled'
           AND reminder_sent = 0
           AND datetime(starts_at, '-' || reminder_offset_minutes || ' minutes') <= datetime('now')
           AND starts_at >= datetime('now')`
      )
      .all();

    for (const appt of due) {
      try {
        sendSms(
          appt.client_phone,
          `Reminder: you have "${appt.title}" scheduled at ${appt.starts_at}${appt.location ? ' at ' + appt.location : ''}.`
        );
        db.prepare('UPDATE appointments SET reminder_sent = 1 WHERE id = ?').run(appt.id);
        logActivity(appt.business_id, 'appointment', appt.id, 'reminder_sent', `Reminder sent to ${appt.client_phone}`);
      } catch (err) {
        console.error(`Failed to send reminder for appointment ${appt.id}:`, err.message);
      }
    }
  });

  console.log('Reminder scheduler started (checks every minute).');
}

module.exports = { startReminderScheduler };
