/**
 * Notification sending is provider-agnostic here. Swap the body of
 * sendSms() for a real integration, for example Twilio:
 *
 *   const twilio = require('twilio')(accountSid, authToken);
 *   twilio.messages.create({ to: phone, from: TWILIO_NUMBER, body: message });
 *
 * or an email/WhatsApp provider for reminders on those channels.
 * Until real credentials are added, reminders are logged to the console
 * and recorded in activity_log so the rest of the system (booking,
 * reminder scheduling, lead follow-up) works end-to-end in development.
 */
function sendSms(phone, message) {
  if (!phone) {
    console.log(`[notifications] Skipped SMS (no phone on file): "${message}"`);
    return;
  }
  console.log(`[notifications] SMS -> ${phone}: ${message}`);
}

function sendEmail(to, subject, body) {
  if (!to) return;
  console.log(`[notifications] EMAIL -> ${to} | ${subject}: ${body}`);
}

module.exports = { sendSms, sendEmail };
