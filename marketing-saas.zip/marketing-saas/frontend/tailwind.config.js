/** @type {import('tailwindcss').Config} */
export default {
  content: ['./index.html', './src/**/*.{js,jsx}'],
  theme: {
    extend: {
      colors: {
        ink: '#12161C',
        paper: '#F7F6F3',
        signal: {
          DEFAULT: '#1B4D3E', // deep emerald - primary brand action color
          light: '#2F6E58',
          dark: '#0F332A',
        },
        amber: {
          DEFAULT: '#C97A2B', // warm amber accent for highlights/reminders
        },
        line: '#E4E1D8',
      },
      fontFamily: {
        display: ['"Fraunces"', 'ui-serif', 'Georgia', 'serif'],
        body: ['"Inter"', 'ui-sans-serif', 'system-ui', 'sans-serif'],
        mono: ['"IBM Plex Mono"', 'ui-monospace', 'monospace'],
      },
      borderRadius: {
        sm: '4px',
        DEFAULT: '8px',
        lg: '14px',
      },
    },
  },
  plugins: [],
};
