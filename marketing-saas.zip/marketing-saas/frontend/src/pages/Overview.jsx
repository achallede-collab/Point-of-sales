import React, { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import api from '../api/client';

function StatCard({ label, value, sub }) {
  return (
    <div className="card p-5">
      <p className="text-xs uppercase tracking-wide text-ink/50">{label}</p>
      <p className="font-display text-3xl mt-1">{value}</p>
      {sub && <p className="text-xs text-ink/50 mt-1">{sub}</p>}
    </div>
  );
}

export default function Overview() {
  const [data, setData] = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    api
      .get('/dashboard/summary')
      .then(({ data }) => setData(data))
      .finally(() => setLoading(false));
  }, []);

  if (loading) return <p className="text-ink/50 font-mono text-sm">Loading overview…</p>;

  const statusMap = Object.fromEntries((data.leadCounts || []).map((c) => [c.status, c.count]));

  return (
    <div className="space-y-8">
      <div>
        <h1 className="font-display text-2xl">Overview</h1>
        <p className="text-ink/60 text-sm mt-1">Here's how your marketing and pipeline are doing right now.</p>
      </div>

      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        <StatCard label="Total leads" value={data.totalLeads} sub={`${data.leadsThisWeek} new this week`} />
        <StatCard label="New" value={statusMap.new || 0} />
        <StatCard label="Qualified" value={statusMap.qualified || 0} />
        <StatCard label="Won" value={statusMap.won || 0} />
      </div>

      <div className="grid md:grid-cols-2 gap-6">
        <div className="card p-5">
          <div className="flex items-center justify-between mb-3">
            <h2 className="font-medium">Upcoming appointments</h2>
            <Link to="/appointments" className="text-xs text-signal hover:underline">View all</Link>
          </div>
          {data.upcomingAppointments.length === 0 ? (
            <p className="text-sm text-ink/50">Nothing booked yet. Book your first appointment to see it here.</p>
          ) : (
            <ul className="divide-y divide-line">
              {data.upcomingAppointments.map((a) => (
                <li key={a.id} className="py-2 text-sm flex justify-between">
                  <div>
                    <p className="font-medium">{a.title}</p>
                    <p className="text-ink/50">{a.client_name}{a.location ? ` · ${a.location}` : ''}</p>
                  </div>
                  <p className="text-ink/50 whitespace-nowrap">{new Date(a.starts_at).toLocaleString()}</p>
                </li>
              ))}
            </ul>
          )}
        </div>

        <div className="card p-5">
          <div className="flex items-center justify-between mb-3">
            <h2 className="font-medium">Connected platforms</h2>
            <Link to="/settings/social" className="text-xs text-signal hover:underline">Manage</Link>
          </div>
          {data.connectedPlatforms.length === 0 ? (
            <p className="text-sm text-ink/50">No social accounts connected yet. Connect one to start running campaigns.</p>
          ) : (
            <div className="flex flex-wrap gap-2">
              {data.connectedPlatforms.map((p) => (
                <span key={p} className="px-3 py-1 bg-signal/10 text-signal text-xs rounded-full capitalize">{p}</span>
              ))}
            </div>
          )}

          <div className="mt-5">
            <h3 className="text-sm font-medium mb-2">Recent campaigns</h3>
            {data.recentCampaigns.length === 0 ? (
              <p className="text-sm text-ink/50">No campaigns yet.</p>
            ) : (
              <ul className="space-y-2">
                {data.recentCampaigns.map((c) => (
                  <li key={c.id} className="text-sm flex justify-between">
                    <span>{c.name}</span>
                    <span className="text-ink/50 capitalize">{c.status}</span>
                  </li>
                ))}
              </ul>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
