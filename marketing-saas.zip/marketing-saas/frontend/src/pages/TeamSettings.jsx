import React, { useEffect, useState } from 'react';
import api from '../api/client';
import { useAuth } from '../context/AuthContext';

export default function TeamSettings() {
  const { user } = useAuth();
  const [team, setTeam] = useState([]);
  const [form, setForm] = useState({ name: '', email: '', password: '', role: 'staff' });
  const [error, setError] = useState('');
  const [success, setSuccess] = useState('');
  const [busy, setBusy] = useState(false);

  async function load() {
    const { data } = await api.get('/business/team');
    setTeam(data.team);
  }

  useEffect(() => { load(); }, []);

  async function invite(e) {
    e.preventDefault();
    setBusy(true);
    setError('');
    setSuccess('');
    try {
      await api.post('/auth/invite', form);
      setSuccess(`${form.name} added to your team.`);
      setForm({ name: '', email: '', password: '', role: 'staff' });
      load();
    } catch (err) {
      setError(err.response?.data?.error || 'Could not invite this teammate.');
    } finally {
      setBusy(false);
    }
  }

  const canInvite = user?.role === 'owner' || user?.role === 'admin';

  return (
    <div className="space-y-6">
      <div>
        <h1 className="font-display text-2xl">Team</h1>
        <p className="text-ink/60 text-sm mt-1">Everyone here shares the same business dashboard.</p>
      </div>

      <div className="card overflow-hidden">
        <table className="w-full text-sm">
          <thead className="bg-ink/5 text-left text-xs uppercase tracking-wide text-ink/50">
            <tr>
              <th className="px-4 py-3">Name</th>
              <th className="px-4 py-3">Email</th>
              <th className="px-4 py-3">Role</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-line">
            {team.map((m) => (
              <tr key={m.id}>
                <td className="px-4 py-3 font-medium">{m.name}</td>
                <td className="px-4 py-3">{m.email}</td>
                <td className="px-4 py-3 capitalize">{m.role}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      {canInvite && (
        <form onSubmit={invite} className="card p-5 grid md:grid-cols-2 gap-3">
          <h2 className="md:col-span-2 font-medium">Invite a teammate</h2>
          {error && <p className="md:col-span-2 text-sm text-red-600">{error}</p>}
          {success && <p className="md:col-span-2 text-sm text-signal">{success}</p>}
          <div>
            <label className="label">Name</label>
            <input required className="input" value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} />
          </div>
          <div>
            <label className="label">Email</label>
            <input required type="email" className="input" value={form.email} onChange={(e) => setForm({ ...form, email: e.target.value })} />
          </div>
          <div>
            <label className="label">Temporary password</label>
            <input required minLength={6} className="input" value={form.password} onChange={(e) => setForm({ ...form, password: e.target.value })} />
          </div>
          <div>
            <label className="label">Role</label>
            <select className="input" value={form.role} onChange={(e) => setForm({ ...form, role: e.target.value })}>
              <option value="staff">Staff</option>
              <option value="admin">Admin</option>
            </select>
          </div>
          <div className="md:col-span-2">
            <button disabled={busy} className="btn-primary">{busy ? 'Inviting…' : 'Add teammate'}</button>
          </div>
        </form>
      )}
    </div>
  );
}
