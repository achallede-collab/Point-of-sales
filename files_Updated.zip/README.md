# VendaPoint POS — Setup Guide

This folder contains everything you need to run VendaPoint POS either
**locally** or **hosted online with a real, persistent database**.

Files:
- `index.html` — the whole application (UI + logic)
- `config.js` — where you put your database credentials
- `schema.sql` — creates your database tables + starter data
- `product-import-template.csv` — example file for bulk product import
- `server.py` — optional local test server

By default (with `config.js` untouched), the app runs in **offline demo
mode**: sample data only, nothing is saved, resets on refresh. Follow
the steps below to switch on a real online database.

---

## Part 1 — Create your online database (Supabase, free)

1. Go to https://supabase.com and sign up (free tier is enough).
2. Click **New project**. Choose a name, set a database password
   (save it somewhere safe), pick a region close to you, and create it.
   Wait ~2 minutes while it provisions.
3. In the left sidebar, open **SQL Editor** → **New query**.
4. Open `schema.sql` from this folder, copy all of it, paste it into
   the editor, and click **Run**. This creates all tables (products,
   staff, transactions, transaction_items, categories,
   business_settings) and fills them with starter/demo data.
5. In the left sidebar, go to **Project Settings** → **API**. Copy:
   - the **Project URL**
   - the **anon public** key
6. Open `config.js` in this folder and paste them in:
   ```js
   const SUPABASE_URL = 'https://xxxxxxxx.supabase.co';
   const SUPABASE_ANON_KEY = 'eyJhbGciOi....................';
   ```
   Save the file.
7. (For logo uploads) In the left sidebar, go to **Storage** → **New
   bucket**. Name it exactly `logos`, toggle **Public bucket** on, and
   create it. This is where uploaded client logos get stored.

That's your database done — products, staff accounts, sales, and
settings will now be read from and written to Supabase instead of
memory.

---

## Part 2 — Host it online

### Easiest: Netlify (drag-and-drop, free, 2 minutes)

1. Go to https://app.netlify.com and sign up (free).
2. On the dashboard, find the **"Deploy manually"** / **"drag and drop
   your site output folder here"** box.
3. Drag this whole folder (containing `index.html` and `config.js`)
   onto that box.
4. Netlify uploads it and gives you a live URL like
   `https://random-name-123.netlify.app` — open it, your POS system
   is now live on the internet with a real database behind it.
5. Optional: in **Site settings → Change site name** to get a nicer
   URL, or connect your own domain under **Domain settings**.

### Alternative: Vercel

1. Go to https://vercel.com, sign up, click **Add New → Project**.
2. Choose **"Deploy without Git"** / drag-and-drop the folder the
   same way as Netlify, or connect a GitHub repo if you have one.
3. Deploy — you'll get a `https://yourapp.vercel.app` URL.

### Alternative: GitHub Pages (free, good if you already use GitHub)

1. Create a new GitHub repository and upload `index.html` and
   `config.js` to it.
2. Go to **Settings → Pages**, set the source branch to `main` and
   folder to `/ (root)`, save.
3. GitHub gives you a URL like
   `https://yourusername.github.io/your-repo/`.

Any of the three works — Netlify is the fastest for a first try.

---

## Testing it locally before you deploy (optional but recommended)

1. Open a terminal in this folder.
2. Run `python3 server.py` (or `python server.py` on Windows).
3. Your browser opens to http://localhost:8000 — sign in and confirm
   data loads (if you set up Supabase already) or that demo mode
   works (if you haven't).

## Demo accounts

| Role    | Username | Password    |
|---------|----------|-------------|
| Admin   | admin    | admin123    |
| Cashier | cashier  | cashier123  |

Once connected to Supabase you can add/edit/remove staff accounts
from the Staff page as an admin — these are the real login accounts
going forward.

---

## Customizing this for a client (no code needed)

Everything below is done from inside the app itself, as an admin —
useful if you're setting this up fresh for a new client business.

### Change the branding (logo, name, address, receipt footer)

Go to **Settings** as an admin:
- Set the **Business Name**, **Address**, **Phone**, **Tax Rate**, and
  the **Receipt Footer Message** (the line printed at the bottom of
  every receipt).
- Click the file picker under **Client / Business Logo** to upload the
  client's logo (PNG/JPG, under 2MB). It appears instantly in the
  sidebar, the login screen, and on printed receipts. Click
  **Remove logo** to go back to plain initials.
  - In offline demo mode the logo only previews for your current
    session (it isn't saved anywhere).
  - Once connected to Supabase (see Part 1, step 7 above), uploaded
    logos are stored permanently in your `logos` bucket.

### Add, rename, or remove product categories

Still in **Settings**, use the **Product Categories** card:
- Type a new category name and click **Add** — it immediately shows
  up as a filter tab in Point of Sale and as an option when adding
  products.
- Click the ✕ on any category chip to remove it. If products still
  use that category, you'll get a warning before it's deleted (the
  products keep their category label, it just won't appear as a
  filter anymore).

### Bulk upload a product list from Excel or CSV

Go to **Inventory** as an admin:
1. Click **Download Excel Template** to get a spreadsheet with the
   correct column headers (`Name, Category, Price, Stock,
   LowStockThreshold, Emoji`). A ready-made example,
   `product-import-template.csv`, is also included in this folder.
2. Fill in your client's product list in that spreadsheet (Excel,
   `.xlsx`, `.xls`, or `.csv` all work). Emoji is optional — leave it
   blank and 🛒 is used as the default icon.
3. Click **Import from Excel**, choose your file. You'll see a
   preview of every row and whether it's valid before anything is
   saved — rows with a missing name/category or an invalid price or
   stock number are flagged and skipped automatically.
4. Click **Import X Product(s)** to add them all at once. Any new
   category names in the file are created automatically.

---



- **MTN MoMo / Orange Money payments are simulated.** The checkout
  flow (enter phone → request sent → confirmed) shows what the
  experience will look like, but no real money moves. To accept real
  mobile money payments you need to register as a merchant with MTN
  and Orange and integrate their payment APIs — ideally called from a
  small server-side function, not directly from the browser.
- **Security note:** this setup uses Supabase's public "anon" key
  directly from the browser with no extra access rules (Row Level
  Security), which is fine for a private/internal prototype but means
  anyone who inspects your site's code has the same database access
  your app does. `schema.sql` has notes at the bottom on hardening
  this (RLS policies, real authentication, moving sensitive calls to
  a backend) before handling real customer payments at scale.
- **Passwords are stored in plain text** in the `staff` table for
  simplicity. Fine for a small internal tool; for anything more
  sensitive, move to Supabase Auth or hash passwords properly.
