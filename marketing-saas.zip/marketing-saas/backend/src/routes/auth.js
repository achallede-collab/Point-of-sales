const express = require('express');
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const { v4: uuidv4 } = require('uuid');
const { body, validationResult } = require('express-validator');
const db = require('../db/db');
const { requireAuth } = require('../middleware/auth');

const router = express.Router();

function slugify(name) {
  return name
    .toLowerCase()
    .trim()
    .replace(/[^a-z0-9]+/g, '-')
    .replace(/(^-|-$)/g, '');
}

function signToken(user) {
  return jwt.sign(
    { sub: user.id, businessId: user.business_id, role: user.role, email: user.email },
    process.env.JWT_SECRET,
    { expiresIn: process.env.JWT_EXPIRES_IN || '7d' }
  );
}

/**
 * POST /api/auth/register
 * Creates a brand new business ("tenant") plus its first owner user.
 * This is how a new business signs up and gets its own dashboard.
 */
router.post(
  '/register',
  [
    body('businessName').trim().notEmpty().withMessage('Business name is required'),
    body('ownerName').trim().notEmpty().withMessage('Your name is required'),
    body('email').isEmail().withMessage('A valid email is required'),
    body('password').isLength({ min: 6 }).withMessage('Password must be at least 6 characters'),
  ],
  (req, res) => {
    const errors = validationResult(req);
    if (!errors.isEmpty()) return res.status(400).json({ errors: errors.array() });

    const { businessName, ownerName, email, password, industry, phone } = req.body;

    const existing = db.prepare('SELECT id FROM users WHERE email = ?').get(email);
    if (existing) return res.status(409).json({ error: 'An account with this email already exists.' });

    let slug = slugify(businessName);
    const slugTaken = db.prepare('SELECT id FROM businesses WHERE slug = ?').get(slug);
    if (slugTaken) slug = `${slug}-${Math.floor(Math.random() * 10000)}`;

    const businessId = uuidv4();
    const userId = uuidv4();
    const passwordHash = bcrypt.hashSync(password, 10);

    const insertBusiness = db.prepare(
      `INSERT INTO businesses (id, name, slug, industry, phone) VALUES (?, ?, ?, ?, ?)`
    );
    const insertUser = db.prepare(
      `INSERT INTO users (id, business_id, name, email, password_hash, role) VALUES (?, ?, ?, ?, ?, 'owner')`
    );

    const tx = db.transaction(() => {
      insertBusiness.run(businessId, businessName, slug, industry || null, phone || null);
      insertUser.run(userId, businessId, ownerName, email, passwordHash);
    });
    tx();

    const user = { id: userId, business_id: businessId, role: 'owner', email };
    const token = signToken(user);

    res.status(201).json({
      token,
      business: { id: businessId, name: businessName, slug },
      user: { id: userId, name: ownerName, email, role: 'owner' },
    });
  }
);

/**
 * POST /api/auth/login
 */
router.post(
  '/login',
  [body('email').isEmail(), body('password').notEmpty()],
  (req, res) => {
    const errors = validationResult(req);
    if (!errors.isEmpty()) return res.status(400).json({ errors: errors.array() });

    const { email, password } = req.body;
    const user = db.prepare('SELECT * FROM users WHERE email = ?').get(email);
    if (!user || !bcrypt.compareSync(password, user.password_hash)) {
      return res.status(401).json({ error: 'Invalid email or password.' });
    }

    const business = db.prepare('SELECT * FROM businesses WHERE id = ?').get(user.business_id);
    const token = signToken(user);

    res.json({
      token,
      business: { id: business.id, name: business.name, slug: business.slug, plan: business.plan },
      user: { id: user.id, name: user.name, email: user.email, role: user.role },
    });
  }
);

/**
 * GET /api/auth/me
 * Returns the logged-in user + their business, used to hydrate the
 * frontend dashboard on refresh.
 */
router.get('/me', requireAuth, (req, res) => {
  const user = db.prepare('SELECT id, name, email, role FROM users WHERE id = ?').get(req.user.id);
  const business = db.prepare('SELECT * FROM businesses WHERE id = ?').get(req.user.businessId);
  res.json({ user, business });
});

/**
 * POST /api/auth/invite
 * Owners/admins can invite additional staff members into the SAME business,
 * so a team can share one dashboard.
 */
router.post(
  '/invite',
  requireAuth,
  [
    body('name').trim().notEmpty(),
    body('email').isEmail(),
    body('password').isLength({ min: 6 }),
    body('role').isIn(['admin', 'staff']),
  ],
  (req, res) => {
    if (!['owner', 'admin'].includes(req.user.role)) {
      return res.status(403).json({ error: 'Only owners or admins can invite staff.' });
    }
    const errors = validationResult(req);
    if (!errors.isEmpty()) return res.status(400).json({ errors: errors.array() });

    const { name, email, password, role } = req.body;
    const existing = db.prepare('SELECT id FROM users WHERE email = ?').get(email);
    if (existing) return res.status(409).json({ error: 'A user with this email already exists.' });

    const id = uuidv4();
    const passwordHash = bcrypt.hashSync(password, 10);
    db.prepare(
      `INSERT INTO users (id, business_id, name, email, password_hash, role) VALUES (?, ?, ?, ?, ?, ?)`
    ).run(id, req.user.businessId, name, email, passwordHash, role);

    res.status(201).json({ id, name, email, role });
  }
);

module.exports = router;
