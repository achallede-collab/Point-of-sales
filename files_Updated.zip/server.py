#!/usr/bin/env python3
"""
VendaPoint POS - local server
------------------------------
Runs a tiny local web server so you can open the POS system at
http://localhost:8000 in your browser.

Requires only Python 3 (already installed on most Mac/Linux systems;
on Windows install it from https://www.python.org/downloads/).

Usage:
    python3 server.py
Then open:
    http://localhost:8000
Press CTRL+C in the terminal to stop the server.
"""
import http.server
import socketserver
import webbrowser
import os

PORT = 8000
DIRECTORY = os.path.dirname(os.path.abspath(__file__))

class Handler(http.server.SimpleHTTPRequestHandler):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, directory=DIRECTORY, **kwargs)

if __name__ == "__main__":
    with socketserver.TCPServer(("", PORT), Handler) as httpd:
        url = f"http://localhost:{PORT}"
        print(f"VendaPoint POS is running at {url}")
        print("Press CTRL+C to stop.")
        try:
            webbrowser.open(url)
        except Exception:
            pass
        try:
            httpd.serve_forever()
        except KeyboardInterrupt:
            print("\nServer stopped.")
