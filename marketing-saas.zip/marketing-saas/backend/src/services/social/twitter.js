const axios = require('axios');

/**
 * X (Twitter) adapter using OAuth 2.0 with PKCE and API v2.
 * Requires a developer app at https://developer.twitter.com with
 * "tweet.read tweet.write users.read offline.access" scopes.
 */

function getAuthorizeUrl(state, codeChallenge) {
  const params = new URLSearchParams({
    response_type: 'code',
    client_id: process.env.TWITTER_CLIENT_ID,
    redirect_uri: process.env.TWITTER_REDIRECT_URI,
    scope: 'tweet.read tweet.write users.read offline.access',
    state,
    code_challenge: codeChallenge,
    code_challenge_method: 'S256',
  });
  return `https://twitter.com/i/oauth2/authorize?${params.toString()}`;
}

async function exchangeCodeForToken(code, codeVerifier) {
  const { data } = await axios.post(
    'https://api.twitter.com/2/oauth2/token',
    new URLSearchParams({
      grant_type: 'authorization_code',
      client_id: process.env.TWITTER_CLIENT_ID,
      redirect_uri: process.env.TWITTER_REDIRECT_URI,
      code,
      code_verifier: codeVerifier,
    }),
    {
      auth: { username: process.env.TWITTER_CLIENT_ID, password: process.env.TWITTER_CLIENT_SECRET },
      headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
    }
  );
  return data; // { access_token, refresh_token, expires_in }
}

async function publishTweet(account, message) {
  const { data } = await axios.post(
    'https://api.twitter.com/2/tweets',
    { text: message },
    { headers: { Authorization: `Bearer ${account.access_token}` } }
  );
  return data; // { data: { id, text } }
}

module.exports = { getAuthorizeUrl, exchangeCodeForToken, publishTweet };
