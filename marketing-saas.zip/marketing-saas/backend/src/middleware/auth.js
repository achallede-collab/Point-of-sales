const jwt = require('jsonwebtoken');
require('dotenv').config();

/**
 * Verifies the JWT sent in the Authorization header and attaches
 * req.user = { id, businessId, role } to the request.
 * This is what makes the system multi-tenant: every downstream route
 * uses req.user.businessId to scope its database queries, so one
 * business can never see another business's data.
 */
function requireAuth(req, res, next) {
  const header = req.headers.authorization || '';
  const token = header.startsWith('Bearer ') ? header.slice(7) : null;

  if (!token) {
    return res.status(401).json({ error: 'Missing authentication token.' });
  }

  try {
    const payload = jwt.verify(token, process.env.JWT_SECRET);
    req.user = {
      id: payload.sub,
      businessId: payload.businessId,
      role: payload.role,
      email: payload.email,
    };
    next();
  } catch (err) {
    return res.status(401).json({ error: 'Invalid or expired token.' });
  }
}

/**
 * Restricts a route to specific roles within a business (e.g. only owners
 * can invite staff or delete the business).
 */
function requireRole(...allowedRoles) {
  return (req, res, next) => {
    if (!req.user || !allowedRoles.includes(req.user.role)) {
      return res.status(403).json({ error: 'You do not have permission to do this.' });
    }
    next();
  };
}

module.exports = { requireAuth, requireRole };
