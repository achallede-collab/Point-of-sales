import React, { useEffect, useState } from 'react';
import api from '../api/client';

const PLATFORMS = ['facebook', 'instagram', 'twitter', 'linkedin'];

function NewCampaignForm({ onCreated }) {
  const [open, setOpen] = useState(false);
  const [form, setForm] = useState({ name: '', message: '', media_url: '', platforms: [], scheduled_at: '' });
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState('');

  function togglePlatform(p) {
    setForm((f) => ({
      ...f,
      platforms: f.platforms.includes(p) ? f.platforms.filter((x) => x !== p) : [...f.platforms, p],
    }));
  }

  async function submit(e, publishNow) {
    e.preventDefault();
    if (form.platforms.length === 0) {
      setError('Select at least one platform to target.');
      return;
    }
    setBusy(true);
    setError('');
    try {
      const payload = {
        ...form,
        publishNow,
        scheduled_at: form.scheduled_at ? new Date(form.scheduled_at).toISOString() : null,
      };
      const { data } = await api.post('/campaigns', payload);
      onCreated(data);
      setForm({ name: '', message: '', media_url: '', platforms: [], scheduled_at: '' });
      setOpen(false);
    } catch (err) {
      setError(err.response?.data?.error || 'Could not save this campaign.');
    } finally {
      setBusy(false);
    }
  }

  if (!open) {
    return <button className="btn-primary" onClick={() => setOpen(true)}>+ New campaign</button>;
  }

  return (
    <form className="card p-5 space-y-3 mb-6">
      {error && <p className="text-sm text-red-600">{error}</p>}
      <div>
        <label className="label">Campaign name</label>
        <input required className="input" value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} />
      </div>
      <div>
        <label className="label">Post message</label>
        <textarea required rows={3} className="input" value={form.message} onChange={(e) => setForm({ ...form, message: e.target.value })} />
      </div>
      <div>
        <label className="label">Image URL (optional)</label>
        <input className="input" value={form.media_url} onChange={(e) => setForm({ ...form, media_url: e.target.value })} />
      </div>
      <div>
        <label className="label">Target platforms</label>
        <div className="flex gap-2 flex-wrap">
          {PLATFORMS.map((p) => (
            <button
              type="button"
              key={p}
              onClick={() => togglePlatform(p)}
              className={`px-3 py-1.5 rounded-full text-xs capitalize border ${
                form.platforms.includes(p) ? 'bg-signal text-white border-signal' : 'border-line text-ink/70'
              }`}
            >
              {p}
            </button>
          ))}
        </div>
      </div>
      <div>
        <label className="label">Schedule for later (optional)</label>
        <input type="datetime-local" className="input" value={form.scheduled_at} onChange={(e) => setForm({ ...form, scheduled_at: e.target.value })} />
      </div>
      <div className="flex gap-2">
        <button disabled={busy} onClick={(e) => submit(e, true)} className="btn-primary">
          {busy ? 'Publishing…' : 'Publish now'}
        </button>
        <button disabled={busy} onClick={(e) => submit(e, false)} className="btn-secondary">
          Save {form.scheduled_at ? '& schedule' : 'as draft'}
        </button>
        <button type="button" className="btn-secondary" onClick={() => setOpen(false)}>Cancel</button>
      </div>
    </form>
  );
}

export default function Campaigns() {
  const [campaigns, setCampaigns] = useState([]);
  const [loading, setLoading] = useState(true);

  async function load() {
    setLoading(true);
    const { data } = await api.get('/campaigns');
    setCampaigns(data.campaigns);
    setLoading(false);
  }

  useEffect(() => { load(); }, []);

  async function publishNow(id) {
    await api.post(`/campaigns/${id}/publish`);
    load();
  }

  const statusColor = {
    draft: 'text-ink/50',
    scheduled: 'text-amber',
    posted: 'text-signal',
    failed: 'text-red-600',
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="font-display text-2xl">Campaigns</h1>
          <p className="text-ink/60 text-sm mt-1">Post once, reach every connected platform.</p>
        </div>
        <NewCampaignForm onCreated={() => load()} />
      </div>

      {loading ? (
        <p className="text-ink/50 text-sm">Loading…</p>
      ) : campaigns.length === 0 ? (
        <p className="text-ink/50 text-sm">No campaigns yet — create your first one above.</p>
      ) : (
        <div className="space-y-4">
          {campaigns.map((c) => (
            <div key={c.id} className="card p-5">
              <div className="flex items-start justify-between">
                <div>
                  <p className="font-medium">{c.name}</p>
                  <p className="text-sm text-ink/60 mt-1 max-w-xl">{c.message}</p>
                  <div className="flex gap-1.5 mt-2 flex-wrap">
                    {c.platforms.map((p) => (
                      <span key={p} className="px-2 py-0.5 bg-ink/5 rounded-full text-xs capitalize">{p}</span>
                    ))}
                  </div>
                </div>
                <div className="text-right">
                  <p className={`text-xs font-medium capitalize ${statusColor[c.status] || ''}`}>{c.status}</p>
                  {c.status !== 'posted' && (
                    <button onClick={() => publishNow(c.id)} className="mt-2 text-xs text-signal hover:underline">
                      Publish now
                    </button>
                  )}
                </div>
              </div>
              {c.results?.length > 0 && (
                <div className="mt-3 pt-3 border-t border-line grid grid-cols-2 md:grid-cols-4 gap-2 text-xs">
                  {c.results.map((r) => (
                    <div key={r.id} className="flex items-center gap-1.5">
                      <span className={`w-1.5 h-1.5 rounded-full ${r.status === 'success' ? 'bg-signal' : 'bg-red-500'}`} />
                      <span className="capitalize">{r.platform}</span>
                      <span className="text-ink/40">{r.status}</span>
                    </div>
                  ))}
                </div>
              )}
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
