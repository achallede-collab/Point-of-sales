const cron = require('node-cron');
const db = require('../db/db');
const { publishCampaign } = require('./publisher');

/**
 * Every minute, publish any campaign whose scheduled_at time has arrived.
 * This is what lets a business "schedule a post for 9am tomorrow across
 * Facebook + Instagram + X" and have it go out automatically.
 */
function startCampaignScheduler() {
  cron.schedule('* * * * *', async () => {
    const due = db
      .prepare(`SELECT * FROM campaigns WHERE status = 'scheduled' AND scheduled_at <= datetime('now')`)
      .all();

    for (const campaign of due) {
      try {
        await publishCampaign(campaign);
      } catch (err) {
        console.error(`Failed to publish scheduled campaign ${campaign.id}:`, err.message);
        db.prepare(`UPDATE campaigns SET status = 'failed' WHERE id = ?`).run(campaign.id);
      }
    }
  });

  console.log('Campaign scheduler started (checks every minute).');
}

module.exports = { startCampaignScheduler };
