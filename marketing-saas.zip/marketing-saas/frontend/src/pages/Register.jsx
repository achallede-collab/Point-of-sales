import React, { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';

export default function Register() {
  const { register } = useAuth();
  const navigate = useNavigate();
  const [form, setForm] = useState({
    businessName: '',
    ownerName: '',
    email: '',
    password: '',
    industry: '',
    phone: '',
  });
  const [error, setError] = useState('');
  const [busy, setBusy] = useState(false);

  function update(field, value) {
    setForm((f) => ({ ...f, [field]: value }));
  }

  async function handleSubmit(e) {
    e.preventDefault();
    setError('');
    setBusy(true);
    try {
      await register(form);
      navigate('/');
    } catch (err) {
      setError(err.response?.data?.error || err.response?.data?.errors?.[0]?.msg || 'Could not create your account.');
    } finally {
      setBusy(false);
    }
  }

  return (
    <div className="min-h-screen flex items-center justify-center bg-paper px-4 py-10">
      <div className="w-full max-w-md">
        <div className="text-center mb-8">
          <p className="font-display text-3xl">Outpost</p>
          <p className="text-ink/60 text-sm mt-1">Set up your own marketing dashboard in a minute</p>
        </div>

        <form onSubmit={handleSubmit} className="card p-6 space-y-4">
          {error && <p className="text-sm text-red-600 bg-red-50 border border-red-200 rounded-sm px-3 py-2">{error}</p>}

          <div>
            <label className="label">Business name</label>
            <input required className="input" value={form.businessName} onChange={(e) => update('businessName', e.target.value)} />
          </div>
          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="label">Industry</label>
              <input className="input" placeholder="e.g. Salon, Real Estate" value={form.industry} onChange={(e) => update('industry', e.target.value)} />
            </div>
            <div>
              <label className="label">Phone</label>
              <input className="input" value={form.phone} onChange={(e) => update('phone', e.target.value)} />
            </div>
          </div>
          <div>
            <label className="label">Your name</label>
            <input required className="input" value={form.ownerName} onChange={(e) => update('ownerName', e.target.value)} />
          </div>
          <div>
            <label className="label">Email</label>
            <input type="email" required className="input" value={form.email} onChange={(e) => update('email', e.target.value)} />
          </div>
          <div>
            <label className="label">Password</label>
            <input type="password" required minLength={6} className="input" value={form.password} onChange={(e) => update('password', e.target.value)} />
          </div>

          <button type="submit" disabled={busy} className="btn-primary w-full">
            {busy ? 'Creating your dashboard…' : 'Create my dashboard'}
          </button>
        </form>

        <p className="text-center text-sm text-ink/60 mt-5">
          Already have an account?{' '}
          <Link to="/login" className="text-signal font-medium hover:underline">
            Sign in
          </Link>
        </p>
      </div>
    </div>
  );
}
