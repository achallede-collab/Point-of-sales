import React, { useEffect, useState } from 'react';
import api from '../api/client';

function BookingForm({ onCreated }) {
  const [open, setOpen] = useState(false);
  const [form, setForm] = useState({
    title: '', client_name: '', client_phone: '', location: '',
    starts_at: '', duration_minutes: 30, reminder_offset_minutes: 60,
  });
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState('');

  async function submit(e) {
    e.preventDefault();
    setBusy(true);
    setError('');
    try {
      const payload = { ...form, starts_at: new Date(form.starts_at).toISOString() };
      const { data } = await api.post('/appointments', payload);
      onCreated(data);
      setForm({ title: '', client_name: '', client_phone: '', location: '', starts_at: '', duration_minutes: 30, reminder_offset_minutes: 60 });
      setOpen(false);
    } catch (err) {
      setError(err.response?.data?.error || 'Could not book this appointment.');
    } finally {
      setBusy(false);
    }
  }

  if (!open) {
    return <button className="btn-primary" onClick={() => setOpen(true)}>+ Book appointment</button>;
  }

  return (
    <form onSubmit={submit} className="card p-5 grid md:grid-cols-2 gap-3 mb-6">
      {error && <p className="md:col-span-2 text-sm text-red-600">{error}</p>}
      <div>
        <label className="label">Appointment title</label>
        <input required className="input" value={form.title} onChange={(e) => setForm({ ...form, title: e.target.value })} />
      </div>
      <div>
        <label className="label">Client name</label>
        <input required className="input" value={form.client_name} onChange={(e) => setForm({ ...form, client_name: e.target.value })} />
      </div>
      <div>
        <label className="label">Client phone (for reminder)</label>
        <input className="input" value={form.client_phone} onChange={(e) => setForm({ ...form, client_phone: e.target.value })} />
      </div>
      <div>
        <label className="label">Location</label>
        <input className="input" value={form.location} onChange={(e) => setForm({ ...form, location: e.target.value })} />
      </div>
      <div>
        <label className="label">Date & time</label>
        <input required type="datetime-local" className="input" value={form.starts_at} onChange={(e) => setForm({ ...form, starts_at: e.target.value })} />
      </div>
      <div className="grid grid-cols-2 gap-3">
        <div>
          <label className="label">Duration (min)</label>
          <input type="number" className="input" value={form.duration_minutes} onChange={(e) => setForm({ ...form, duration_minutes: Number(e.target.value) })} />
        </div>
        <div>
          <label className="label">Remind before (min)</label>
          <input type="number" className="input" value={form.reminder_offset_minutes} onChange={(e) => setForm({ ...form, reminder_offset_minutes: Number(e.target.value) })} />
        </div>
      </div>
      <div className="md:col-span-2 flex gap-2">
        <button type="submit" disabled={busy} className="btn-primary">{busy ? 'Booking…' : 'Book appointment'}</button>
        <button type="button" className="btn-secondary" onClick={() => setOpen(false)}>Cancel</button>
      </div>
    </form>
  );
}

export default function Appointments() {
  const [appointments, setAppointments] = useState([]);
  const [loading, setLoading] = useState(true);

  async function load() {
    setLoading(true);
    const { data } = await api.get('/appointments');
    setAppointments(data.appointments);
    setLoading(false);
  }

  useEffect(() => { load(); }, []);

  async function setStatus(id, status) {
    setAppointments((prev) => prev.map((a) => (a.id === id ? { ...a, status } : a)));
    await api.patch(`/appointments/${id}`, { status });
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="font-display text-2xl">Appointments</h1>
          <p className="text-ink/60 text-sm mt-1">Bookings and automated reminders for your clients.</p>
        </div>
        <BookingForm onCreated={() => load()} />
      </div>

      <div className="card overflow-hidden">
        <table className="w-full text-sm">
          <thead className="bg-ink/5 text-left text-xs uppercase tracking-wide text-ink/50">
            <tr>
              <th className="px-4 py-3">When</th>
              <th className="px-4 py-3">Title</th>
              <th className="px-4 py-3">Client</th>
              <th className="px-4 py-3">Location</th>
              <th className="px-4 py-3">Reminder</th>
              <th className="px-4 py-3">Status</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-line">
            {loading ? (
              <tr><td className="px-4 py-4 text-ink/50" colSpan={6}>Loading…</td></tr>
            ) : appointments.length === 0 ? (
              <tr><td className="px-4 py-4 text-ink/50" colSpan={6}>No appointments booked yet.</td></tr>
            ) : (
              appointments.map((a) => (
                <tr key={a.id}>
                  <td className="px-4 py-3 whitespace-nowrap">{new Date(a.starts_at).toLocaleString()}</td>
                  <td className="px-4 py-3 font-medium">{a.title}</td>
                  <td className="px-4 py-3">{a.client_name}{a.client_phone ? ` · ${a.client_phone}` : ''}</td>
                  <td className="px-4 py-3">{a.location || '—'}</td>
                  <td className="px-4 py-3">
                    {a.reminder_sent ? (
                      <span className="text-signal text-xs">Sent</span>
                    ) : (
                      <span className="text-ink/50 text-xs">{a.reminder_offset_minutes}m before</span>
                    )}
                  </td>
                  <td className="px-4 py-3">
                    <select
                      className="input py-1 text-xs"
                      value={a.status}
                      onChange={(e) => setStatus(a.id, e.target.value)}
                    >
                      <option value="scheduled">scheduled</option>
                      <option value="completed">completed</option>
                      <option value="cancelled">cancelled</option>
                      <option value="no_show">no show</option>
                    </select>
                  </td>
                </tr>
              ))
            )}
          </tbody>
        </table>
      </div>
    </div>
  );
}
