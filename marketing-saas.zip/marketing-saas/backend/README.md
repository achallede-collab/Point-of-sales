# Marketing SaaS — Backend

Multi-tenant API for a social media marketing + CRM platform. Each business
that signs up gets its own isolated data (leads, appointments, campaigns,
connected social accounts) scoped by `business_id`, and its own dashboard.

## Stack
- Node.js + Express
- SQLite (via `better-sqlite3`) — zero setup, file-based. Swap for Postgres/MySQL later by replacing `src/db/db.js`.
- JWT auth (`jsonwebtoken` + `bcryptjs`)
- `node-cron` for appointment reminders + scheduled campaign publishing

## Setup
```bash
cd backend
npm install
cp .env.example .env      # then edit .env — set JWT_SECRET at minimum
npm run seed               # optional: creates a demo business + login
npm run dev                 # starts on http://localhost:4000
```

Demo login after seeding: `demo@example.com` / `password123`

## Folder structure
```
src/
  index.js                 # app entrypoint, mounts routes + cron jobs
  db/db.js                 # SQLite connection + schema (auto-created)
  middleware/auth.js        # JWT verification, attaches req.user.businessId
  routes/
    auth.js                # register business, login, invite team members
    business.js             # business profile + team
    leads.js                 # lead capture, filtering, pipeline status, timeline
    appointments.js          # booking, rescheduling, cancellation
    social.js                 # OAuth connect/callback per platform
    campaigns.js              # create/schedule/publish campaigns
    dashboard.js               # summary stats for the dashboard home page
  services/
    activity.js               # timeline/audit logging
    notifications.js          # SMS/email sending (stubbed — plug in Twilio etc.)
    reminders.js               # cron: sends appointment reminders
    campaignScheduler.js         # cron: auto-publishes scheduled campaigns
    publisher.js                  # posts a campaign out to every targeted platform
    social/meta.js, twitter.js, linkedin.js   # per-platform OAuth + posting
```

## Connecting real social platforms
Posting to Facebook/Instagram/X/LinkedIn requires you to register a developer
app on each platform and put the client id/secret in `.env`. Until you do,
the "Connect" buttons will still work for wiring UI/UX, but the OAuth
exchange will fail — the code path and API call shapes are all in place in
`src/services/social/*.js`, so you only need to supply credentials.

## Multi-tenancy model
- `businesses` = one row per company/tenant.
- `users.business_id` ties every team member to exactly one business.
- Every other table (`leads`, `appointments`, `campaigns`, `social_accounts`)
  has a `business_id` column, and every route filters `WHERE business_id = ?`
  using the id embedded in the requester's JWT — so Business A can never see
  Business B's data, and each business's dashboard is naturally isolated
  just by who is logged in.
- To let a business invite teammates onto the same dashboard, use
  `POST /api/auth/invite` (owner/admin only).

## Key endpoints
| Method | Path | Purpose |
|---|---|---|
| POST | /api/auth/register | Create a new business + owner account |
| POST | /api/auth/login | Log in |
| POST | /api/auth/invite | Add a teammate to your business |
| GET/POST/PATCH/DELETE | /api/leads | Lead capture & pipeline |
| GET | /api/leads/:id/timeline | Follow-up history for a prospect |
| GET/POST/PATCH/DELETE | /api/appointments | Booking + reminders |
| GET | /api/social/accounts | List connected platforms |
| GET | /api/social/connect/:platform | Start OAuth |
| GET | /api/social/callback/:platform | OAuth redirect target |
| GET/POST | /api/campaigns | Create & list campaigns |
| POST | /api/campaigns/:id/publish | Publish now |
| GET | /api/dashboard/summary | Everything the dashboard home needs |
