const express = require('express');
const { v4: uuidv4 } = require('uuid');
const { body, validationResult } = require('express-validator');
const db = require('../db/db');
const { requireAuth } = require('../middleware/auth');
const { publishCampaign } = require('../services/publisher');
const { logActivity } = require('../services/activity');

const router = express.Router();
router.use(requireAuth);

/**
 * GET /api/campaigns
 * Lists all campaigns for the business with their per-platform results.
 */
router.get('/', (req, res) => {
  const campaigns = db
    .prepare('SELECT * FROM campaigns WHERE business_id = ? ORDER BY created_at DESC')
    .all(req.user.businessId);

  const withResults = campaigns.map((c) => ({
    ...c,
    platforms: JSON.parse(c.platforms),
    results: db.prepare('SELECT * FROM campaign_results WHERE campaign_id = ?').all(c.id),
  }));

  res.json({ campaigns: withResults });
});

/**
 * POST /api/campaigns
 * Creates a campaign targeting one or more connected social platforms.
 * If `scheduled_at` is omitted, it's saved as a draft; pass publishNow=true
 * to post immediately.
 */
router.post(
  '/',
  [
    body('name').trim().notEmpty(),
    body('message').trim().notEmpty(),
    body('platforms').isArray({ min: 1 }).withMessage('Select at least one platform'),
  ],
  async (req, res) => {
    const errors = validationResult(req);
    if (!errors.isEmpty()) return res.status(400).json({ errors: errors.array() });

    const { name, message, media_url, platforms, scheduled_at, publishNow } = req.body;
    const id = uuidv4();
    const status = publishNow ? 'draft' : scheduled_at ? 'scheduled' : 'draft';

    db.prepare(
      `INSERT INTO campaigns (id, business_id, name, message, media_url, platforms, status, scheduled_at)
       VALUES (?, ?, ?, ?, ?, ?, ?, ?)`
    ).run(id, req.user.businessId, name, message, media_url || null, JSON.stringify(platforms), status, scheduled_at || null);

    logActivity(req.user.businessId, 'campaign', id, 'created', name);

    let campaign = db.prepare('SELECT * FROM campaigns WHERE id = ?').get(id);

    if (publishNow) {
      const results = await publishCampaign(campaign);
      campaign = db.prepare('SELECT * FROM campaigns WHERE id = ?').get(id);
      return res.status(201).json({ ...campaign, platforms, results });
    }

    res.status(201).json({ ...campaign, platforms });
  }
);

/**
 * POST /api/campaigns/:id/publish
 * Manually publish a draft or scheduled campaign right now.
 */
router.post('/:id/publish', async (req, res) => {
  const campaign = db
    .prepare('SELECT * FROM campaigns WHERE id = ? AND business_id = ?')
    .get(req.params.id, req.user.businessId);
  if (!campaign) return res.status(404).json({ error: 'Campaign not found.' });

  const results = await publishCampaign(campaign);
  const updated = db.prepare('SELECT * FROM campaigns WHERE id = ?').get(req.params.id);
  res.json({ ...updated, platforms: JSON.parse(updated.platforms), results });
});

router.delete('/:id', (req, res) => {
  const result = db
    .prepare('DELETE FROM campaigns WHERE id = ? AND business_id = ?')
    .run(req.params.id, req.user.businessId);
  if (result.changes === 0) return res.status(404).json({ error: 'Campaign not found.' });
  res.status(204).send();
});

module.exports = router;
