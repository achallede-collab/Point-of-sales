const { v4: uuidv4 } = require('uuid');
const db = require('../db/db');

/**
 * Records a timeline event against a lead/appointment/campaign so a
 * business can see the full history of how a prospect was followed up.
 */
function logActivity(businessId, entityType, entityId, action, detail = null) {
  db.prepare(
    `INSERT INTO activity_log (id, business_id, entity_type, entity_id, action, detail)
     VALUES (?, ?, ?, ?, ?, ?)`
  ).run(uuidv4(), businessId, entityType, entityId, action, detail);
}

module.exports = { logActivity };
