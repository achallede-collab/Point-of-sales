/* ============================================================
   VendaPoint POS — configuration
   ------------------------------------------------------------
   Paste your own Supabase project values below to connect the
   app to a real, online database. Find them in your Supabase
   project under: Project Settings -> API.

   Leave these as-is (with "YOUR-PROJECT" in the URL) to keep the
   app running in OFFLINE DEMO MODE, using in-memory sample data
   that resets on every page refresh.
   ============================================================ */

const SUPABASE_URL = 'https://YOUR-PROJECT-REF.supabase.co';
const SUPABASE_ANON_KEY = 'YOUR-ANON-PUBLIC-KEY';
