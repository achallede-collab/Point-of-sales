-- ============================================================
-- VendaPoint POS — Supabase database schema
-- ------------------------------------------------------------
-- How to use:
--   1. Open your Supabase project -> SQL Editor -> New query.
--   2. Paste this whole file and click "Run".
--   3. That's it — all tables + starter data are created.
-- ============================================================

-- Categories --------------------------------------------------
create table if not exists categories (
  id serial primary key,
  name text unique not null
);

-- Products ------------------------------------------------------
create table if not exists products (
  id text primary key,
  name text not null,
  category text not null,
  price numeric not null default 0,
  stock integer not null default 0,
  low_stock integer not null default 5,
  emoji text default '🛒'
);

-- Staff logins (admin / cashier) --------------------------------
-- NOTE: for a real production system, don't store plain-text
-- passwords in a plain table like this — use Supabase Auth
-- (or hash passwords) instead. This simple table is fine for a
-- prototype / small internal tool.
create table if not exists staff (
  id text primary key,
  name text not null,
  username text unique not null,
  password text not null,
  role text not null check (role in ('admin','cashier'))
);

-- Transactions ----------------------------------------------------
create table if not exists transactions (
  id text primary key,
  date timestamptz not null default now(),
  cashier text not null,
  subtotal numeric not null,
  tax numeric not null,
  total numeric not null,
  payment_method text not null,
  phone text,
  confirmation_code text,
  status text default 'Completed'
);

-- Transaction line items -------------------------------------------
create table if not exists transaction_items (
  id serial primary key,
  transaction_id text references transactions(id) on delete cascade,
  product_id text,
  name text not null,
  price numeric not null,
  qty integer not null
);

-- Business settings (single row) -----------------------------------
create table if not exists business_settings (
  id integer primary key default 1,
  name text,
  address text,
  phone text,
  tax_rate numeric default 19.25,
  footer text,
  logo_url text,
  constraint single_row check (id = 1)
);
-- if you ran an earlier version of this schema before logo support was added:
alter table business_settings add column if not exists logo_url text;

-- ============================================================
-- Starter / seed data
-- ============================================================

insert into categories (name) values
  ('Beverages'),('Groceries'),('Snacks'),('Household'),('Airtime & Data'),('Other')
on conflict (name) do nothing;

insert into products (id,name,category,price,stock,low_stock,emoji) values
  ('P001','Coca-Cola 50cl','Beverages',500,48,10,'🥤'),
  ('P002','Top Soda 50cl','Beverages',450,36,10,'🧃'),
  ('P003','Malta Guinness 33cl','Beverages',700,8,10,'🍺'),
  ('P004','Mineral Water 1.5L','Beverages',600,60,15,'💧'),
  ('P005','Rice 5kg','Groceries',4500,22,5,'🍚'),
  ('P006','Cooking Oil 1L','Groceries',1800,30,8,'🛢️'),
  ('P007','Sugar 1kg','Groceries',900,3,8,'🧂'),
  ('P008','Tomato Paste','Groceries',350,50,10,'🥫'),
  ('P009','Biscuits Pack','Snacks',400,40,10,'🍪'),
  ('P010','Plantain Chips','Snacks',300,25,8,'🍌'),
  ('P011','Groundnuts 200g','Snacks',500,18,6,'🥜'),
  ('P012','Bar Soap','Household',350,45,10,'🧼'),
  ('P013','Detergent 1kg','Household',1500,20,6,'🧴'),
  ('P014','Candles (pack)','Household',600,15,5,'🕯️'),
  ('P015','MTN Airtime 1000F','Airtime & Data',1000,999,0,'📱'),
  ('P016','Orange Airtime 1000F','Airtime & Data',1000,999,0,'📶')
on conflict (id) do nothing;

insert into staff (id,name,username,password,role) values
  ('U001','Admin User','admin','admin123','admin'),
  ('U002','Aicha B.','cashier','cashier123','cashier'),
  ('U003','Junior N.','cashier2','cashier123','cashier')
on conflict (id) do nothing;

insert into business_settings (id,name,address,phone,tax_rate,footer) values
  (1,'Sunrise Mini-Mart','Carrefour Warda, Yaoundé, Cameroon','+237 6 77 12 34 56',19.25,
   'Thank you for shopping with us! No refunds without receipt.')
on conflict (id) do nothing;

-- ============================================================
-- Storage bucket for client logos (do this in the dashboard, not SQL)
-- ------------------------------------------------------------
-- The app lets an admin upload a business/client logo from the
-- Settings page. For that to work online, create a Storage bucket:
--   1. In Supabase, go to Storage (left sidebar) -> "New bucket".
--   2. Name it exactly:  logos
--   3. Toggle "Public bucket" ON, then create it.
-- That's it — no SQL needed for this part. Logos will be stored
-- there and their public URL saved into business_settings.logo_url.
-- ============================================================

-- ============================================================
-- Security note (read before going live with real customers)
-- ------------------------------------------------------------
-- These tables are created WITHOUT Row Level Security (RLS), so
-- your Supabase anon key (used by the front-end) has full read
-- and write access to them. That's fine for a private prototype
-- or an internal tool only your staff can reach, but it means
-- anyone who inspects your website's code could also read/write
-- your data directly.
--
-- Before using this with real customers and real money, consider:
--   1. Enabling RLS on every table above (Authentication -> Policies).
--   2. Adding proper policies scoped to authenticated Supabase users
--      instead of the shared anon key.
--   3. Moving the MTN MoMo / Orange Money API calls to a small
--      server-side function (e.g. a Supabase Edge Function) so API
--      secrets never sit in the browser.
-- ============================================================
