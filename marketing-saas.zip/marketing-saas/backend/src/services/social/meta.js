const axios = require('axios');

/**
 * Meta (Facebook Pages + Instagram Business) adapter.
 * Requires a Meta developer app: https://developers.facebook.com/apps
 * with the pages_manage_posts, pages_read_engagement and
 * instagram_content_publish permissions approved for your app.
 */

function getAuthorizeUrl(state) {
  const params = new URLSearchParams({
    client_id: process.env.META_APP_ID,
    redirect_uri: process.env.META_REDIRECT_URI,
    state,
    scope: 'pages_show_list,pages_manage_posts,pages_read_engagement,instagram_basic,instagram_content_publish',
  });
  return `https://www.facebook.com/v20.0/dialog/oauth?${params.toString()}`;
}

async function exchangeCodeForToken(code) {
  const { data } = await axios.get('https://graph.facebook.com/v20.0/oauth/access_token', {
    params: {
      client_id: process.env.META_APP_ID,
      client_secret: process.env.META_APP_SECRET,
      redirect_uri: process.env.META_REDIRECT_URI,
      code,
    },
  });
  return data; // { access_token, token_type, expires_in }
}

/**
 * Publishes a text + optional image post to a connected Facebook Page.
 * `account.external_account_id` should hold the Page ID, and
 * `account.access_token` a Page access token (obtained after exchanging
 * the user token for page tokens via /me/accounts).
 */
async function publishToPage(account, message, mediaUrl) {
  const endpoint = mediaUrl
    ? `https://graph.facebook.com/v20.0/${account.external_account_id}/photos`
    : `https://graph.facebook.com/v20.0/${account.external_account_id}/feed`;

  const payload = mediaUrl
    ? { url: mediaUrl, caption: message, access_token: account.access_token }
    : { message, access_token: account.access_token };

  const { data } = await axios.post(endpoint, payload);
  return data; // { id, post_id }
}

module.exports = { getAuthorizeUrl, exchangeCodeForToken, publishToPage };
