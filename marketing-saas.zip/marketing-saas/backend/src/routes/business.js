const express = require('express');
const db = require('../db/db');
const { requireAuth, requireRole } = require('../middleware/auth');

const router = express.Router();
router.use(requireAuth);

/**
 * GET /api/business
 * Returns the current business's profile, so its own dashboard can be
 * branded/labeled correctly ("X Business's Dashboard").
 */
router.get('/', (req, res) => {
  const business = db.prepare('SELECT * FROM businesses WHERE id = ?').get(req.user.businessId);
  res.json({ business });
});

/**
 * PATCH /api/business
 * Update the business profile (name, industry, phone, timezone).
 */
router.patch('/', requireRole('owner', 'admin'), (req, res) => {
  const fields = ['name', 'industry', 'phone', 'timezone'];
  const updates = [];
  const params = [];
  for (const f of fields) {
    if (req.body[f] !== undefined) {
      updates.push(`${f} = ?`);
      params.push(req.body[f]);
    }
  }
  if (updates.length === 0) return res.status(400).json({ error: 'No fields to update.' });

  params.push(req.user.businessId);
  db.prepare(`UPDATE businesses SET ${updates.join(', ')} WHERE id = ?`).run(...params);

  const business = db.prepare('SELECT * FROM businesses WHERE id = ?').get(req.user.businessId);
  res.json({ business });
});

/**
 * GET /api/business/team
 * Lists every staff member on this business's account.
 */
router.get('/team', (req, res) => {
  const team = db
    .prepare('SELECT id, name, email, role, created_at FROM users WHERE business_id = ?')
    .all(req.user.businessId);
  res.json({ team });
});

module.exports = router;
