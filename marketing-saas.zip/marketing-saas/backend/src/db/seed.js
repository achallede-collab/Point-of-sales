/**
 * Optional: run `npm run seed` to create a demo business with sample
 * leads and appointments so you can explore the dashboard immediately.
 */
const bcrypt = require('bcryptjs');
const { v4: uuidv4 } = require('uuid');
const db = require('./db');

const businessId = uuidv4();
const userId = uuidv4();

db.prepare(`INSERT INTO businesses (id, name, slug, industry, phone) VALUES (?, ?, ?, ?, ?)`).run(
  businessId, 'Demo Beauty Salon', 'demo-beauty-salon', 'Beauty & Wellness', '+15551234567'
);

db.prepare(
  `INSERT INTO users (id, business_id, name, email, password_hash, role) VALUES (?, ?, ?, ?, ?, 'owner')`
).run(userId, businessId, 'Demo Owner', 'demo@example.com', bcrypt.hashSync('password123', 10));

const leads = [
  ['Amaka Obi', '+2348012345678', 'Lagos, NG', 'facebook', 'new'],
  ['John Doe', '+2348098765432', 'Abuja, NG', 'instagram', 'contacted'],
  ['Grace Chen', '+2348055554444', 'Port Harcourt, NG', 'website', 'qualified'],
];
for (const [name, phone, location, source, status] of leads) {
  db.prepare(
    `INSERT INTO leads (id, business_id, name, phone, location, source, status) VALUES (?, ?, ?, ?, ?, ?, ?)`
  ).run(uuidv4(), businessId, name, phone, location, source, status);
}

const apptId = uuidv4();
db.prepare(
  `INSERT INTO appointments (id, business_id, title, client_name, client_phone, location, starts_at)
   VALUES (?, ?, ?, ?, ?, ?, datetime('now', '+1 day'))`
).run(apptId, businessId, 'Consultation', 'Amaka Obi', '+2348012345678', 'Main Branch');

console.log('Seed complete.');
console.log('Login with: demo@example.com / password123');
