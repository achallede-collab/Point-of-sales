const express = require('express');
const crypto = require('crypto');
const { v4: uuidv4 } = require('uuid');
const db = require('../db/db');
const { requireAuth } = require('../middleware/auth');
const meta = require('../services/social/meta');
const twitter = require('../services/social/twitter');
const linkedin = require('../services/social/linkedin');

const router = express.Router();

// In-memory OAuth state store: state -> { businessId, platform, codeVerifier }
// (swap for Redis in production if you run multiple server instances)
const pendingOAuth = new Map();

/**
 * GET /api/social/accounts
 * Lists every social account connected to the logged-in business, so the
 * dashboard can show "Connected" / "Connect" status per platform.
 */
router.get('/accounts', requireAuth, (req, res) => {
  const accounts = db
    .prepare('SELECT id, platform, account_name, status, connected_at FROM social_accounts WHERE business_id = ?')
    .all(req.user.businessId);
  res.json({ accounts });
});

/**
 * GET /api/social/connect/:platform
 * Kicks off the OAuth flow for a given platform. The frontend redirects the
 * user's browser to the returned `url`.
 */
router.get('/connect/:platform', requireAuth, (req, res) => {
  const { platform } = req.params;
  const state = crypto.randomBytes(16).toString('hex');

  let url;
  if (platform === 'facebook' || platform === 'instagram') {
    pendingOAuth.set(state, { businessId: req.user.businessId, platform });
    url = meta.getAuthorizeUrl(state);
  } else if (platform === 'twitter') {
    const codeVerifier = crypto.randomBytes(32).toString('hex');
    const codeChallenge = crypto
      .createHash('sha256')
      .update(codeVerifier)
      .digest('base64')
      .replace(/=/g, '')
      .replace(/\+/g, '-')
      .replace(/\//g, '_');
    pendingOAuth.set(state, { businessId: req.user.businessId, platform, codeVerifier });
    url = twitter.getAuthorizeUrl(state, codeChallenge);
  } else if (platform === 'linkedin') {
    pendingOAuth.set(state, { businessId: req.user.businessId, platform });
    url = linkedin.getAuthorizeUrl(state);
  } else {
    return res.status(400).json({ error: `Unsupported platform: ${platform}` });
  }

  res.json({ url });
});

/**
 * GET /api/social/callback/:platform
 * The provider redirects here after the business owner approves access.
 * We exchange the temporary `code` for an access token and store the
 * connected account against the business.
 */
router.get('/callback/:platform', async (req, res) => {
  const { platform } = req.params;
  const { code, state } = req.query;

  const pending = pendingOAuth.get(state);
  if (!pending || pending.platform !== platform) {
    return res.status(400).send('Invalid or expired OAuth state. Please try connecting again.');
  }
  pendingOAuth.delete(state);

  try {
    let tokenData, accountName = platform, externalId = null;

    if (platform === 'facebook' || platform === 'instagram') {
      tokenData = await meta.exchangeCodeForToken(code);
    } else if (platform === 'twitter') {
      tokenData = await twitter.exchangeCodeForToken(code, pending.codeVerifier);
    } else if (platform === 'linkedin') {
      tokenData = await linkedin.exchangeCodeForToken(code);
    } else {
      return res.status(400).send('Unsupported platform.');
    }

    const id = uuidv4();
    db.prepare(
      `INSERT INTO social_accounts (id, business_id, platform, account_name, external_account_id, access_token, refresh_token, token_expires_at)
       VALUES (?, ?, ?, ?, ?, ?, ?, ?)`
    ).run(
      id,
      pending.businessId,
      platform,
      accountName,
      externalId,
      tokenData.access_token,
      tokenData.refresh_token || null,
      tokenData.expires_in ? new Date(Date.now() + tokenData.expires_in * 1000).toISOString() : null
    );

    // Redirect back to the frontend dashboard's social settings page
    res.redirect(`${process.env.CLIENT_ORIGIN}/settings/social?connected=${platform}`);
  } catch (err) {
    console.error('OAuth callback error:', err.response?.data || err.message);
    res.redirect(`${process.env.CLIENT_ORIGIN}/settings/social?error=${platform}`);
  }
});

/**
 * DELETE /api/social/accounts/:id
 * Disconnects a platform from the business.
 */
router.delete('/accounts/:id', requireAuth, (req, res) => {
  const result = db
    .prepare('DELETE FROM social_accounts WHERE id = ? AND business_id = ?')
    .run(req.params.id, req.user.businessId);
  if (result.changes === 0) return res.status(404).json({ error: 'Account not found.' });
  res.status(204).send();
});

module.exports = router;
