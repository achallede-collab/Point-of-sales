const express = require('express');
const db = require('../db/db');
const { requireAuth } = require('../middleware/auth');

const router = express.Router();
router.use(requireAuth);

/**
 * GET /api/dashboard/summary
 * A single call that powers the business's main dashboard: lead counts by
 * status, upcoming appointments, connected platforms, and recent campaign
 * performance.
 */
router.get('/summary', (req, res) => {
  const businessId = req.user.businessId;

  const leadCounts = db
    .prepare('SELECT status, COUNT(*) as count FROM leads WHERE business_id = ? GROUP BY status')
    .all(businessId);

  const totalLeads = db.prepare('SELECT COUNT(*) as count FROM leads WHERE business_id = ?').get(businessId).count;

  const leadsThisWeek = db
    .prepare(`SELECT COUNT(*) as count FROM leads WHERE business_id = ? AND created_at >= datetime('now', '-7 days')`)
    .get(businessId).count;

  const upcomingAppointments = db
    .prepare(
      `SELECT * FROM appointments WHERE business_id = ? AND status = 'scheduled' AND starts_at >= datetime('now')
       ORDER BY starts_at ASC LIMIT 5`
    )
    .all(businessId);

  const connectedPlatforms = db
    .prepare(`SELECT platform FROM social_accounts WHERE business_id = ? AND status = 'connected'`)
    .all(businessId)
    .map((r) => r.platform);

  const recentCampaigns = db
    .prepare('SELECT * FROM campaigns WHERE business_id = ? ORDER BY created_at DESC LIMIT 5')
    .all(businessId)
    .map((c) => ({ ...c, platforms: JSON.parse(c.platforms) }));

  const campaignPerformance = db
    .prepare(
      `SELECT cr.platform, COUNT(*) as posts, SUM(cr.reach) as reach, SUM(cr.clicks) as clicks, SUM(cr.leads_generated) as leads
       FROM campaign_results cr
       JOIN campaigns c ON c.id = cr.campaign_id
       WHERE c.business_id = ? AND cr.status = 'success'
       GROUP BY cr.platform`
    )
    .all(businessId);

  res.json({
    totalLeads,
    leadsThisWeek,
    leadCounts,
    upcomingAppointments,
    connectedPlatforms,
    recentCampaigns,
    campaignPerformance,
  });
});

module.exports = router;
