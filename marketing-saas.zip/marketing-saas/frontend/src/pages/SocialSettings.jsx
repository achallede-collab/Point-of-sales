import React, { useEffect, useState } from 'react';
import { useSearchParams } from 'react-router-dom';
import api from '../api/client';

const PLATFORMS = [
  { key: 'facebook', label: 'Facebook Pages' },
  { key: 'instagram', label: 'Instagram Business' },
  { key: 'twitter', label: 'X (Twitter)' },
  { key: 'linkedin', label: 'LinkedIn' },
];

export default function SocialSettings() {
  const [accounts, setAccounts] = useState([]);
  const [loading, setLoading] = useState(true);
  const [params] = useSearchParams();

  async function load() {
    setLoading(true);
    const { data } = await api.get('/social/accounts');
    setAccounts(data.accounts);
    setLoading(false);
  }

  useEffect(() => { load(); }, []);

  async function connect(platform) {
    const { data } = await api.get(`/social/connect/${platform}`);
    window.location.href = data.url;
  }

  async function disconnect(id) {
    await api.delete(`/social/accounts/${id}`);
    load();
  }

  const connectedNotice = params.get('connected');
  const errorNotice = params.get('error');

  return (
    <div className="space-y-6">
      <div>
        <h1 className="font-display text-2xl">Social accounts</h1>
        <p className="text-ink/60 text-sm mt-1">Connect the platforms you want to run campaigns on.</p>
      </div>

      {connectedNotice && (
        <p className="text-sm text-signal bg-signal/10 border border-signal/20 rounded-sm px-3 py-2 capitalize">
          {connectedNotice} connected successfully.
        </p>
      )}
      {errorNotice && (
        <p className="text-sm text-red-600 bg-red-50 border border-red-200 rounded-sm px-3 py-2 capitalize">
          Could not connect {errorNotice}. Check your app credentials in the backend .env file.
        </p>
      )}

      <div className="grid md:grid-cols-2 gap-4">
        {PLATFORMS.map((p) => {
          const connected = accounts.find((a) => a.platform === p.key);
          return (
            <div key={p.key} className="card p-5 flex items-center justify-between">
              <div>
                <p className="font-medium">{p.label}</p>
                <p className="text-xs text-ink/50 mt-0.5">
                  {connected ? `Connected ${new Date(connected.connected_at).toLocaleDateString()}` : 'Not connected'}
                </p>
              </div>
              {connected ? (
                <button className="btn-secondary text-xs" onClick={() => disconnect(connected.id)}>Disconnect</button>
              ) : (
                <button className="btn-primary text-xs" onClick={() => connect(p.key)}>Connect</button>
              )}
            </div>
          );
        })}
      </div>

      <p className="text-xs text-ink/40">
        Connecting requires the business to have created a developer app on that platform, with the
        client id/secret set in the backend's .env file. See backend/README.md for details.
      </p>
    </div>
  );
}
