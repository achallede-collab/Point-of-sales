import React from 'react';
import { NavLink, Outlet } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';

const navItems = [
  { to: '/', label: 'Overview', end: true },
  { to: '/leads', label: 'Leads' },
  { to: '/appointments', label: 'Appointments' },
  { to: '/campaigns', label: 'Campaigns' },
  { to: '/settings/social', label: 'Social accounts' },
  { to: '/settings/team', label: 'Team' },
];

export default function DashboardLayout() {
  const { user, business, logout } = useAuth();

  return (
    <div className="min-h-screen flex">
      <aside className="w-60 shrink-0 border-r border-line bg-white flex flex-col">
        <div className="px-5 py-5 border-b border-line">
          <p className="font-display text-lg leading-tight">{business?.name || 'Your business'}</p>
          <p className="text-xs text-ink/50 mt-0.5">outpost.app/{business?.slug}</p>
        </div>
        <nav className="flex-1 px-3 py-4 space-y-1">
          {navItems.map((item) => (
            <NavLink
              key={item.to}
              to={item.to}
              end={item.end}
              className={({ isActive }) =>
                `block px-3 py-2 rounded-sm text-sm font-medium transition-colors ${
                  isActive ? 'bg-signal text-white' : 'text-ink/70 hover:bg-paper hover:text-ink'
                }`
              }
            >
              {item.label}
            </NavLink>
          ))}
        </nav>
        <div className="px-5 py-4 border-t border-line">
          <p className="text-sm font-medium">{user?.name}</p>
          <p className="text-xs text-ink/50 mb-3">{user?.role}</p>
          <button onClick={logout} className="text-xs text-ink/50 hover:text-signal underline">
            Sign out
          </button>
        </div>
      </aside>
      <main className="flex-1 bg-paper">
        <div className="max-w-6xl mx-auto px-8 py-8">
          <Outlet />
        </div>
      </main>
    </div>
  );
}
