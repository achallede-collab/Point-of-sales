import React, { useEffect, useState } from 'react';
import api from '../api/client';

const STATUSES = ['new', 'contacted', 'qualified', 'won', 'lost'];

function NewLeadForm({ onCreated }) {
  const [open, setOpen] = useState(false);
  const [form, setForm] = useState({ name: '', phone: '', location: '', source: 'manual', notes: '' });
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState('');

  async function submit(e) {
    e.preventDefault();
    setBusy(true);
    setError('');
    try {
      const { data } = await api.post('/leads', form);
      onCreated(data);
      setForm({ name: '', phone: '', location: '', source: 'manual', notes: '' });
      setOpen(false);
    } catch (err) {
      setError(err.response?.data?.error || 'Could not save this lead.');
    } finally {
      setBusy(false);
    }
  }

  if (!open) {
    return (
      <button className="btn-primary" onClick={() => setOpen(true)}>
        + Add lead
      </button>
    );
  }

  return (
    <form onSubmit={submit} className="card p-5 grid md:grid-cols-2 gap-3 mb-6">
      {error && <p className="md:col-span-2 text-sm text-red-600">{error}</p>}
      <div>
        <label className="label">Name</label>
        <input required className="input" value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} />
      </div>
      <div>
        <label className="label">Phone number</label>
        <input required className="input" value={form.phone} onChange={(e) => setForm({ ...form, phone: e.target.value })} />
      </div>
      <div>
        <label className="label">Location</label>
        <input className="input" value={form.location} onChange={(e) => setForm({ ...form, location: e.target.value })} />
      </div>
      <div>
        <label className="label">Source</label>
        <select className="input" value={form.source} onChange={(e) => setForm({ ...form, source: e.target.value })}>
          <option value="manual">Manual entry</option>
          <option value="facebook">Facebook</option>
          <option value="instagram">Instagram</option>
          <option value="website">Website</option>
          <option value="referral">Referral</option>
        </select>
      </div>
      <div className="md:col-span-2">
        <label className="label">Notes</label>
        <textarea className="input" rows={2} value={form.notes} onChange={(e) => setForm({ ...form, notes: e.target.value })} />
      </div>
      <div className="md:col-span-2 flex gap-2">
        <button type="submit" disabled={busy} className="btn-primary">{busy ? 'Saving…' : 'Save lead'}</button>
        <button type="button" className="btn-secondary" onClick={() => setOpen(false)}>Cancel</button>
      </div>
    </form>
  );
}

export default function Leads() {
  const [leads, setLeads] = useState([]);
  const [total, setTotal] = useState(0);
  const [statusFilter, setStatusFilter] = useState('');
  const [search, setSearch] = useState('');
  const [loading, setLoading] = useState(true);

  async function load() {
    setLoading(true);
    const params = {};
    if (statusFilter) params.status = statusFilter;
    if (search) params.search = search;
    const { data } = await api.get('/leads', { params });
    setLeads(data.leads);
    setTotal(data.total);
    setLoading(false);
  }

  useEffect(() => {
    load();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [statusFilter]);

  async function updateStatus(id, status) {
    setLeads((prev) => prev.map((l) => (l.id === id ? { ...l, status } : l)));
    await api.patch(`/leads/${id}`, { status });
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="font-display text-2xl">Leads</h1>
          <p className="text-ink/60 text-sm mt-1">{total} total · saved with phone number & location for follow-up</p>
        </div>
        <NewLeadForm onCreated={() => load()} />
      </div>

      <div className="flex gap-2 flex-wrap items-center">
        <input
          className="input max-w-xs"
          placeholder="Search name, phone, location…"
          value={search}
          onChange={(e) => setSearch(e.target.value)}
          onKeyDown={(e) => e.key === 'Enter' && load()}
        />
        <button className="btn-secondary" onClick={load}>Search</button>
        <select className="input max-w-[160px]" value={statusFilter} onChange={(e) => setStatusFilter(e.target.value)}>
          <option value="">All statuses</option>
          {STATUSES.map((s) => (
            <option key={s} value={s}>{s}</option>
          ))}
        </select>
      </div>

      <div className="card overflow-hidden">
        <table className="w-full text-sm">
          <thead className="bg-ink/5 text-left text-xs uppercase tracking-wide text-ink/50">
            <tr>
              <th className="px-4 py-3">Name</th>
              <th className="px-4 py-3">Phone</th>
              <th className="px-4 py-3">Location</th>
              <th className="px-4 py-3">Source</th>
              <th className="px-4 py-3">Status</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-line">
            {loading ? (
              <tr><td className="px-4 py-4 text-ink/50" colSpan={5}>Loading…</td></tr>
            ) : leads.length === 0 ? (
              <tr><td className="px-4 py-4 text-ink/50" colSpan={5}>No leads yet — add your first one above.</td></tr>
            ) : (
              leads.map((lead) => (
                <tr key={lead.id}>
                  <td className="px-4 py-3 font-medium">{lead.name}</td>
                  <td className="px-4 py-3">{lead.phone}</td>
                  <td className="px-4 py-3">{lead.location || '—'}</td>
                  <td className="px-4 py-3 capitalize">{lead.source}</td>
                  <td className="px-4 py-3">
                    <select
                      className="input py-1 text-xs"
                      value={lead.status}
                      onChange={(e) => updateStatus(lead.id, e.target.value)}
                    >
                      {STATUSES.map((s) => (
                        <option key={s} value={s}>{s}</option>
                      ))}
                    </select>
                  </td>
                </tr>
              ))
            )}
          </tbody>
        </table>
      </div>
    </div>
  );
}
