import React, { createContext, useContext, useEffect, useState } from 'react';
import api from '../api/client';

const AuthContext = createContext(null);

export function AuthProvider({ children }) {
  const [user, setUser] = useState(() => JSON.parse(localStorage.getItem('outpost_user') || 'null'));
  const [business, setBusiness] = useState(() => JSON.parse(localStorage.getItem('outpost_business') || 'null'));
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const token = localStorage.getItem('outpost_token');
    if (!token) {
      setLoading(false);
      return;
    }
    api
      .get('/auth/me')
      .then(({ data }) => {
        setUser(data.user);
        setBusiness(data.business);
        localStorage.setItem('outpost_user', JSON.stringify(data.user));
        localStorage.setItem('outpost_business', JSON.stringify(data.business));
      })
      .catch(() => {})
      .finally(() => setLoading(false));
  }, []);

  function persistSession({ token, user, business }) {
    localStorage.setItem('outpost_token', token);
    localStorage.setItem('outpost_user', JSON.stringify(user));
    localStorage.setItem('outpost_business', JSON.stringify(business));
    setUser(user);
    setBusiness(business);
  }

  async function login(email, password) {
    const { data } = await api.post('/auth/login', { email, password });
    persistSession(data);
    return data;
  }

  async function register(payload) {
    const { data } = await api.post('/auth/register', payload);
    persistSession(data);
    return data;
  }

  function logout() {
    localStorage.removeItem('outpost_token');
    localStorage.removeItem('outpost_user');
    localStorage.removeItem('outpost_business');
    setUser(null);
    setBusiness(null);
  }

  return (
    <AuthContext.Provider value={{ user, business, loading, login, register, logout }}>
      {children}
    </AuthContext.Provider>
  );
}

export function useAuth() {
  return useContext(AuthContext);
}
