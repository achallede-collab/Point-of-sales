# VendaPoint POS — Local Setup

A self-contained Point of Sale prototype (admin + cashier dashboards,
MTN MoMo / Orange Money checkout simulation, printable receipts).
No installation, database, or internet connection required to run it.

## Option 1 — Just open the file (easiest)

Double-click **index.html**. It opens directly in your browser and works
fully offline. This is the fastest way to try it out.

## Option 2 — Run it on localhost

Some browsers restrict certain features when a page is opened directly
from disk (`file://`). Running it through a local server avoids that and
mirrors how it would run on a real host.

**Requires:** Python 3 (already installed on most Mac/Linux machines; on
Windows, install from https://www.python.org/downloads/ and check
"Add Python to PATH" during install).

1. Open a terminal / command prompt in this folder (`vendapoint-pos`).
2. Run:
   ```
   python3 server.py
   ```
   (On Windows, if `python3` isn't recognized, try `python server.py`.)
3. Your browser will open automatically to **http://localhost:8000**.
   If not, open that address manually.
4. Press `CTRL + C` in the terminal when you're done, to stop the server.

### Prefer Node.js instead of Python?

If you have Node installed, you can use `npx` instead — no install needed:
```
npx http-server -p 8000
```
Then open http://localhost:8000.

## Demo accounts

| Role    | Username | Password    |
|---------|----------|-------------|
| Admin   | admin    | admin123    |
| Cashier | cashier  | cashier123  |

## Important notes

- **Data is in-memory only.** Refreshing the page resets products, sales,
  and staff back to the demo seed data — there's no database yet.
- **MTN MoMo / Orange Money payments are simulated** for this prototype
  (no real money moves). To go live, you'd register for MTN MoMo and
  Orange Money merchant/API access and swap the simulated request in
  `index.html` for real API calls.
- Everything (HTML, CSS, JS) lives in the single `index.html` file, so
  it's easy to hand to a developer to extend or connect to a backend.
