const express = require('express');
const { v4: uuidv4 } = require('uuid');
const { body, validationResult } = require('express-validator');
const db = require('../db/db');
const { requireAuth } = require('../middleware/auth');
const { logActivity } = require('../services/activity');

const router = express.Router();
router.use(requireAuth);

/**
 * GET /api/leads
 * Supports ?status=&source=&search=&page=&pageSize= for filtering the
 * lead list (e.g. finding all "new" leads from Facebook in a city).
 */
router.get('/', (req, res) => {
  const { status, source, search, page = 1, pageSize = 25 } = req.query;
  const clauses = ['business_id = ?'];
  const params = [req.user.businessId];

  if (status) { clauses.push('status = ?'); params.push(status); }
  if (source) { clauses.push('source = ?'); params.push(source); }
  if (search) {
    clauses.push('(name LIKE ? OR phone LIKE ? OR location LIKE ?)');
    const like = `%${search}%`;
    params.push(like, like, like);
  }

  const where = clauses.join(' AND ');
  const offset = (Number(page) - 1) * Number(pageSize);

  const rows = db
    .prepare(`SELECT * FROM leads WHERE ${where} ORDER BY created_at DESC LIMIT ? OFFSET ?`)
    .all(...params, Number(pageSize), offset);

  const total = db.prepare(`SELECT COUNT(*) AS count FROM leads WHERE ${where}`).get(...params).count;

  res.json({ leads: rows, total, page: Number(page), pageSize: Number(pageSize) });
});

/**
 * POST /api/leads
 * Saves a new lead with phone number and location (the core requirement:
 * leads can be generated - manually, from a landing page, or from a
 * connected social campaign - and stored against the business).
 */
router.post(
  '/',
  [
    body('name').trim().notEmpty().withMessage('Name is required'),
    body('phone').trim().notEmpty().withMessage('Phone number is required'),
    body('location').optional({ checkFalsy: true }).trim(),
  ],
  (req, res) => {
    const errors = validationResult(req);
    if (!errors.isEmpty()) return res.status(400).json({ errors: errors.array() });

    const { name, phone, email, location, source, notes, assigned_to } = req.body;
    const id = uuidv4();

    db.prepare(
      `INSERT INTO leads (id, business_id, name, phone, email, location, source, notes, assigned_to)
       VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)`
    ).run(id, req.user.businessId, name, phone, email || null, location || null, source || 'manual', notes || null, assigned_to || null);

    logActivity(req.user.businessId, 'lead', id, 'created', `Lead ${name} added`);

    const lead = db.prepare('SELECT * FROM leads WHERE id = ?').get(id);
    res.status(201).json(lead);
  }
);

/**
 * PATCH /api/leads/:id
 * Updates lead details or moves it through the pipeline
 * (new -> contacted -> qualified -> won/lost), i.e. "following up" a prospect.
 */
router.patch('/:id', (req, res) => {
  const existing = db
    .prepare('SELECT * FROM leads WHERE id = ? AND business_id = ?')
    .get(req.params.id, req.user.businessId);
  if (!existing) return res.status(404).json({ error: 'Lead not found.' });

  const fields = ['name', 'phone', 'email', 'location', 'source', 'status', 'notes', 'assigned_to'];
  const updates = [];
  const params = [];
  for (const f of fields) {
    if (req.body[f] !== undefined) {
      updates.push(`${f} = ?`);
      params.push(req.body[f]);
    }
  }
  if (updates.length === 0) return res.status(400).json({ error: 'No fields to update.' });

  updates.push("updated_at = datetime('now')");
  params.push(req.params.id, req.user.businessId);

  db.prepare(`UPDATE leads SET ${updates.join(', ')} WHERE id = ? AND business_id = ?`).run(...params);
  logActivity(req.user.businessId, 'lead', req.params.id, 'updated', JSON.stringify(req.body));

  const updated = db.prepare('SELECT * FROM leads WHERE id = ?').get(req.params.id);
  res.json(updated);
});

/**
 * DELETE /api/leads/:id
 */
router.delete('/:id', (req, res) => {
  const result = db
    .prepare('DELETE FROM leads WHERE id = ? AND business_id = ?')
    .run(req.params.id, req.user.businessId);
  if (result.changes === 0) return res.status(404).json({ error: 'Lead not found.' });
  res.status(204).send();
});

/**
 * GET /api/leads/:id/timeline
 * Shows the full follow-up history of a prospect: activity log entries
 * plus any linked appointments.
 */
router.get('/:id/timeline', (req, res) => {
  const lead = db
    .prepare('SELECT * FROM leads WHERE id = ? AND business_id = ?')
    .get(req.params.id, req.user.businessId);
  if (!lead) return res.status(404).json({ error: 'Lead not found.' });

  const activity = db
    .prepare(`SELECT * FROM activity_log WHERE business_id = ? AND entity_type = 'lead' AND entity_id = ? ORDER BY created_at DESC`)
    .all(req.user.businessId, req.params.id);

  const appointments = db
    .prepare(`SELECT * FROM appointments WHERE business_id = ? AND lead_id = ? ORDER BY starts_at DESC`)
    .all(req.user.businessId, req.params.id);

  res.json({ lead, activity, appointments });
});

module.exports = router;
